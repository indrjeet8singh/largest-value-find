﻿using DataAccessLayer;
using CommanLayer.Models;
using System;
using System.Collections.Generic;

namespace BussinessLayer
{
    public class BLEmployeeBussiness
    {
        private EmployeeDataAccessDb employeeData;
        public BLEmployeeBussiness()
        {
            employeeData = new EmployeeDataAccessDb();
        }
        public List<Employees> GetEmployees()
        {
            return employeeData.GetEmployees();
        }
    }
}
