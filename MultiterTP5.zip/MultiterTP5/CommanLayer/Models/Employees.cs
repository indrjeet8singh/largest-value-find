﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommanLayer.Models
{
   public class Employees
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Gender { get; set; }
    }
}
