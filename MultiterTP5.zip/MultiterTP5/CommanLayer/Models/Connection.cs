﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommanLayer.Models
{
   public class Connection
    {
        public static string ConnectionStr { get; set; }
    }
}
