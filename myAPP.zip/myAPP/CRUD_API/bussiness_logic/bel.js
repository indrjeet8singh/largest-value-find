
const express=require('express')
const app=express()
const { Console } = require('winston/lib/winston/transports');
const logger=require('../controller/logger')
const Employee=require('../model/userModel')
const fs=require('fs')


// This Route For Create the data

exports.create =async   function (req, res) {
    try{
    var contact = new Employee();
    contact.name = req.body.name ? req.body.name : contact.name;
    contact.gender = req.body.gender;
    contact.email = req.body.email;
    contact.phone = req.body.phone;
    contact.password=req.body.password;
    contact.save(function (err) {
            res.json({
            message: 'New contact created!',
            data: contact
        });
        logger.info(`successfully create ${res}`)
      });
}
            catch(error){
              logger.error('error find in creating the data')
                  return res.status(500).json({message: "Problem with Creating the Employee recored "})
                }
          
              }



// this route for read all data

exports.read=async (req, res) => {
    try{
    const readData=await Employee.find({})
    res.json({
        message: 'You successfully login',
        data: readData
        });
    logger.info(`successfully read ${res}`)
  }

        catch(err){
          logger.error('error find in read the data')
          return res.status(500).json({message: "Problem with Read the Employee recored "})
          
        }
    }


// this route for read the data by id

exports.readbyID=async (req, res) => {
    try{
        const _id=req.params.id;
    const readDatabyID=await Employee.findById(_id)
    res.json({
        message: 'You successfully read the data by ID',
        data: readDatabyID
        });
    logger.info(`successfully read ${res}`)
  }

        catch(err){
          logger.error('error find in read the data')
          return res.status(500).json({message: "Problem with Read the Employee recored "})
          
        }
    }


// this route for updating the data

exports.update=async (req,res)=>{

  const thing = new Employee({
      _id: req.params.id,
      name: req.body.name,
      email: req.body.email,
      phone: req.body.phone,
      gender: req.body.gender,
      password: req.body.password
    });
    Employee.updateOne({_id: req.params.id}, thing).then(
      () => {
        res.status(201).json({
            message: 'You successfully update the data ',  
            data: thing
        });
      }
    ).catch ((error)=> {
            logger.error('error find in updating the data')
            return res.status(500).json({message: "Problem with updating the Employee recored "})
          }
    )}


// this route for deleting the data

exports.delete=async (req,res)=>{
  try {
    const _id=req.params.id;
    const deleteUser=await Employee.findByIdAndDelete(req.params.id)
    res.json({
        message: 'You successfully delete the data',
        data: deleteUser
        });
    logger.info(`successfully delete ${res}`)

  } catch (error) {
    logger.error('error find in deleting the data')

    return res.status(500).json({message: "Problem with deleting the Employee recored "})
  }
}

// this route using for upload a video

exports.uploadVideo= (req,res)=>{
  // try {
    
    // app.get('/video', function(req, res) {
    
      const path = 'D:\mov_bbb.mp4'
      const stat = fs.statSync(path)
      const fileSize = stat.size
      const range = req.headers.range

      if (range) {
        const parts = range.replace(/bytes=/, "").split("-")
        const start = parseInt(parts[0], 10)
        const end = parts[1] 
          ? parseInt(parts[1], 10)
          : fileSize-1
        const chunksize = (end-start)+1
        const file = fs.createReadStream(path, {start, end})
      
        const head = {
          'Content-Range': `bytes ${start}-${end}/${fileSize}`,
          'Accept-Ranges': 'bytes',
          'Content-Length': chunksize,
          'Content-Type': 'D:\mov_bbb.mp4',
        }
        res.writeHead(206, head);
        file.pipe(res);
      } else {
        const head = {
          'Content-Length': fileSize,
          'Content-Type': 'video/mp4',
        }
        res.writeHead(200, head)
        fs.createReadStream(path).pipe(res)
      }
    };
