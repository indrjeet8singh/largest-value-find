
require('./model/database');

const express = require('express');
const path = require('path');
const bodyparser = require('body-parser');
const apiRoutes=require('./router/routes')
var app = express();
app.use(bodyparser.urlencoded({extended: true}));
app.use(bodyparser.json());
app.use('/api', apiRoutes);
app.listen(3000, () => {
    console.log('Express server started at port : 3000');
});

module.exports=app;