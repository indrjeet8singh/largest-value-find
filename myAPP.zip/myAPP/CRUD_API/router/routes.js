
let router = require('express').Router();
var pizza=require('../controller/pizzaController')



router.route('/create')
.post(pizza.create)

router.route('/read')
.get(pizza.read)

router.route('/read/:id')
.get(pizza.readbyID)

router.route('/update/:id')
.put(pizza.update)


router.route('/delete/:id')
.delete(pizza.delete)

router.route('/uploadVideo')
.post(pizza.uploadVideo)

module.exports=router;







