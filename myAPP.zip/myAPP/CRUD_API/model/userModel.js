
var mongoose = require('mongoose');

var crudSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique:true
    },
    gender: String,
    phone: String,
    create_date: {
        type: Date,
        default: Date.now
    },
    password:{
        type:String,
        required:true
    },
   
});


var Employee = module.exports = mongoose.model('employee', crudSchema);
module.exports.get = function (callback, limit) {
    Employee.find(callback).limit(limit);
}